# Agent instructions — HighLevel / GoHighLevel

When implementing anything that touches HighLevel:

- Read `docs/API_MAP.md` and `docs/VELARQO_PRIORITY.md` first.
- If `vendor/highlevel-api-docs/` exists, treat its OpenAPI/JSON/Markdown files as the primary local API source.
- Never invent an endpoint, scope, webhook, field, trigger, workflow action, plan entitlement, or rate limit.
- Prefer private integrations for Velarqo-internal/single-account tooling unless OAuth/Marketplace distribution is actually required.
- Treat workflows as GHL execution/orchestration, not as the only place for Velarqo intelligence. Keep complex scoring, enrichment, segmentation, experimentation, analytics, and reusable business logic outside GHL when that improves portability/testability.
- Build idempotently: upsert contacts where appropriate, store GHL IDs, deduplicate events, verify webhook signatures/auth, and make retries safe.
- Respect DND/consent/compliance state and do not create outbound automations that bypass it.
- For every integration, document: scopes, endpoints, webhook events, custom fields, pipeline stages, retry strategy, rate-limit handling, failure modes, and test fixtures.
- If docs disagree, prefer the newest official Developer Portal page for the exact API version being used.
