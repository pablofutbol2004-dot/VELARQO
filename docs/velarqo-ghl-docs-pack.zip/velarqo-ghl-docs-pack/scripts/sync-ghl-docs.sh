#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
VENDOR="$ROOT/vendor"
mkdir -p "$VENDOR"

sync_repo() {
  local name="$1" url="$2" path="$VENDOR/$1"
  if [ -d "$path/.git" ]; then
    git -C "$path" fetch --depth 1 origin main
    git -C "$path" reset --hard origin/main
  else
    rm -rf "$path"
    git clone --depth 1 "$url" "$path"
  fi
}

sync_repo highlevel-api-docs https://github.com/GoHighLevel/highlevel-api-docs.git
sync_repo highlevel-api-sdk https://github.com/GoHighLevel/highlevel-api-sdk.git

echo "Done. Official HighLevel API docs and SDK are in $VENDOR"
