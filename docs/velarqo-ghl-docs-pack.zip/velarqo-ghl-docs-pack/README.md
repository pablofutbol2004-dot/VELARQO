# Velarqo — HighLevel documentation pack

Updated: 2026-09-27

Purpose: give coding agents working on Velarqo a reliable map of GoHighLevel/HighLevel (GHL) features, product documentation, API documentation, webhooks, auth, and official SDKs.

## What is included

- `docs/FEATURE_MAP.md` — broad map of HighLevel modules and capabilities.
- `docs/SUPPORT_PORTAL_INDEX.md` — canonical HighLevel help-center sections for UI/product behavior.
- `docs/API_MAP.md` — API surfaces, auth, webhooks, v2/v3 notes, and official repos.
- `docs/VELARQO_PRIORITY.md` — which parts matter most for a home-services automation business.
- `docs/SOURCES.yaml` — machine-readable source registry.
- `AGENTS_GHL.md` — instructions for Claude Code / Codex / Cursor agents.
- `scripts/sync-ghl-docs.ps1` — Windows PowerShell sync script for the complete official API docs + SDK repos.
- `scripts/sync-ghl-docs.sh` — bash equivalent.
- `vendor/` — destination for official repositories after sync.

## First setup

From the Velarqo repo root, put this folder at `docs/ghl/`, then run:

```powershell
powershell -ExecutionPolicy Bypass -File .\docs\ghl\scripts\sync-ghl-docs.ps1
```

This clones/updates HighLevel's official API docs and SDK into `vendor/`.

## Source-of-truth policy

1. For API schemas/endpoints, prefer the local official `vendor/highlevel-api-docs` repo after sync.
2. For current UI behavior and feature configuration, use the official Support Portal links in `SUPPORT_PORTAL_INDEX.md`.
3. For authentication, scopes, webhooks, and Marketplace apps, prefer the current Developer Portal.
4. Do not rely on old v1 examples. HighLevel marks v1 end-of-support as 2025-12-31.
5. Check version headers and docs version before implementing; HighLevel is actively adding v3 endpoints.

## Why the Support Portal is not copied wholesale

HighLevel's Support Portal is large and changes continuously. This pack stores a canonical index instead of a stale mirror. The API docs are different: HighLevel publishes their source as a public GitHub repository, so the sync scripts vendor that machine-readable material directly.
