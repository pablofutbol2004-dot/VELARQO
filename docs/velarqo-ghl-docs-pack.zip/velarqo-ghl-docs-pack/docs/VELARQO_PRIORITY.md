# What matters most for Velarqo

For a performance-based home-services growth/DB-reactivation system, prioritize these HighLevel areas in roughly this implementation order:

## Tier 1 — core delivery
1. Contacts, custom fields, tags, DND/consent state
2. Opportunities, pipelines, stages, monetary value
3. Conversations + SMS/email
4. Workflows, triggers, actions, waits, branches
5. Calendars / booked appointments
6. Forms/surveys where lead capture or qualification needs them
7. Reporting + attribution

## Tier 2 — important for operational quality
8. Phone system and call tracking
9. Reputation/review requests
10. Payments/invoices if Velarqo bills inside GHL
11. Snapshots for repeatable client onboarding
12. Agency/sub-account permissions and configuration

## Tier 3 — use only if the use case proves it
13. Conversation AI / Voice AI
14. Agent Studio / Workflow AI
15. SaaS configurator / white-label resale
16. Sites/funnels/store/community/course features

## Recommended architecture

**Outside GHL (Velarqo intelligence):**
- database analysis and cleanup
- lead/customer segmentation
- scoring and propensity logic
- campaign strategy generation
- experiments and versioning
- analytics/modeling beyond native dashboards
- reusable cross-client business logic
- cold-outreach infrastructure if it is not a client-owned GHL channel

**Inside GHL (execution + CRM state):**
- contacts and lifecycle state
- custom fields/tags
- conversations
- workflow execution
- appointment booking
- opportunities/pipeline
- operational notifications
- review requests
- client-visible reporting where native GHL is sufficient

This split keeps Velarqo portable if you change niche or CRM while still exploiting GHL's execution layer.
